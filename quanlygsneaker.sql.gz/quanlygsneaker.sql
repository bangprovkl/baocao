-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2021 at 08:45 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quanlygsneaker`
--

-- --------------------------------------------------------

--
-- Table structure for table `chitiethd`
--

CREATE TABLE `chitiethd` (
  `maHD` varchar(50) NOT NULL,
  `ngaytao` date NOT NULL,
  `maSP` varchar(50) NOT NULL,
  `maKH` varchar(50) NOT NULL,
  `soluongban` int(11) NOT NULL,
  `thanhtien` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chitiethd`
--

INSERT INTO `chitiethd` (`maHD`, `ngaytao`, `maSP`, `maKH`, `soluongban`, `thanhtien`) VALUES
('HD1', '2021-03-03', 'V1', 'KH07', 1, 350000),
('HD3', '2021-03-03', 'V1', 'KH04', 1, 350000),
('HD1', '2021-03-03', 'P2', 'KH07', 2, 700000),
('HD3', '2021-03-03', 'N1', 'KH04', 4, 1000000),
('HD4', '2021-06-16', 'P3', 'KH08', 2, 700000),
('HD1', '2021-03-03', 'N2', 'KH07', 1, 450000),
('HD6', '2021-02-03', 'N1', 'KH06', 2, 500000),
('HD12', '2021-07-07', 'N1', 'KH04', 3, 750000),
('HD12', '2021-07-07', 'N2', 'KH04', 1, 450000),
('HD12', '2021-07-07', 'V1', 'KH04', 2, 700000),
('HD10', '2020-01-01', 'N1', 'KH08', 1, 250000),
('HD', '2021-04-03', 'V1', 'KH01', 1, 350000);

-- --------------------------------------------------------

--
-- Table structure for table `hoadon`
--

CREATE TABLE `hoadon` (
  `maHD` varchar(50) NOT NULL,
  `ngaytao` date NOT NULL,
  `tong` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hoadon`
--

INSERT INTO `hoadon` (`maHD`, `ngaytao`, `tong`) VALUES
('HD', '2021-04-03', 350000),
('HD1', '2021-03-03', 1500000),
('HD10', '2020-01-01', 250000),
('HD12', '2021-07-07', 1900000),
('HD3', '2021-03-03', 1350000),
('HD4', '2021-06-16', 700000),
('HD6', '2021-02-03', 500000);

-- --------------------------------------------------------

--
-- Table structure for table `khachhang`
--

CREATE TABLE `khachhang` (
  `maKH` varchar(50) NOT NULL,
  `tenKH` varchar(50) NOT NULL,
  `gioitinh` varchar(50) NOT NULL,
  `diachi` varchar(50) NOT NULL,
  `sdt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `khachhang`
--

INSERT INTO `khachhang` (`maKH`, `tenKH`, `gioitinh`, `diachi`, `sdt`) VALUES
('KH01', 'Nguyễn Thị Lan', 'Nữ', 'Hà Nội', 335821631),
('KH02', 'Nguyễn Văn Nam', 'nam', 'Thái Bình', 91241041),
('KH03', 'Trần Nhật Nam', 'nam', 'Ninh Bình', 8337153),
('KH04', 'Hà Minh Ngọc', 'Nữ', 'Hoàng Mai', 203354881),
('Kh05', 'Trần Mai Anh', 'Nam', 'Hoàn Kiếm ,Hà Nội', 33421883),
('KH06', 'Trần Thị Ly', 'Nữ', 'Nguyễn Phong Sắc , HN', 335421443),
('KH07', 'Nguyễn Lâm', 'Nam', 'Nguyễn Ngọc Vũ ,HN', 445315432),
('KH08', 'Nguyễn Nhật Thi', 'Nam', 'Nguyễn Chí  Thanh,Ba Đình,Hà Nội', 343224331);

-- --------------------------------------------------------

--
-- Table structure for table `loaisanpham`
--

CREATE TABLE `loaisanpham` (
  `maloaiSP` varchar(50) NOT NULL,
  `tenloaiSP` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `loaisanpham`
--

INSERT INTO `loaisanpham` (`maloaiSP`, `tenloaiSP`) VALUES
('Nike', 'Nike01'),
('Puma', 'Puma01'),
('Vans', 'Vans01');

-- --------------------------------------------------------

--
-- Table structure for table `nhanvien`
--

CREATE TABLE `nhanvien` (
  `maTK` varchar(50) NOT NULL,
  `maNV` varchar(50) NOT NULL,
  `tenNV` varchar(50) NOT NULL,
  `Diachi` varchar(50) NOT NULL,
  `sdt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nhanvien`
--

INSERT INTO `nhanvien` (`maTK`, `maNV`, `tenNV`, `Diachi`, `sdt`) VALUES
('TK01', 'NV01', 'Lại Hồng Vy', '51,Định Công,Hoàng Mai,Hà Nội', 32112161),
('TK02', 'NV02', 'Đặng Nam', '32 Dương Đình Nghệ, Yên Hòa,Hà Nội', 43424665),
('TK03', 'NV03', 'Nguyễn Văn Đông', 'Bắc Ninh', 355577334),
('TK04', 'NV04', 'Triệu Thảo Nhi', 'Nam Định', 318266181);

-- --------------------------------------------------------

--
-- Table structure for table `nhasanxuat`
--

CREATE TABLE `nhasanxuat` (
  `maNSX` varchar(50) NOT NULL,
  `tenNSX` varchar(50) NOT NULL,
  `diachi` varchar(50) NOT NULL,
  `sdt` int(11) NOT NULL,
  `mail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nhasanxuat`
--

INSERT INTO `nhasanxuat` (`maNSX`, `tenNSX`, `diachi`, `sdt`, `mail`) VALUES
('NSX01', 'NSXNike', 'Hà Nội', 34217833, 'NSXNike@gmail.com'),
('NSX02', 'NSXVans', 'Trung Quốc', 33517331, 'NSXVans@gmail.com'),
('NSX03', 'NSXPuma', 'Đức', 34217833, 'NSXPuma@gmail.com'),
('NSX04', 'NSXConverse', 'Mỹ', 34217833, 'NSXConverse@gmail.com'),
('NSX05', 'NSXAdidas', 'Mỹ', 3134334, 'NSXAdidas@gmail.com'),
('NSX06', 'NSXConverse', 'Mỹ', 34217837, 'NSXConverse2@gmail.com'),
('NSX07', 'NSXNike', 'Hồ Chí Minh', 34217830, 'NSXNike2@gmail.com'),
('NSX08', 'NSXNike', 'Đà Nẵng', 54217852, 'NSXNike3@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `maloaiSP` varchar(50) NOT NULL,
  `maSP` varchar(50) NOT NULL,
  `tenSP` varchar(50) NOT NULL,
  `size` int(11) NOT NULL,
  `mausac` varchar(50) NOT NULL,
  `soluong` int(11) NOT NULL,
  `maNSX` varchar(50) NOT NULL,
  `gia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`maloaiSP`, `maSP`, `tenSP`, `size`, `mausac`, `soluong`, `maNSX`, `gia`) VALUES
('Nike', 'N1', 'Giày Nike', 36, 'xanh trắng', 5, 'NSX01', 250000),
('Nike', 'N2', 'Giày Nike Air Force', 36, 'trắng', 6, 'NSX01', 450000),
('Nike', 'N3', 'Nike Air Max', 40, 'đen', 8, 'NSX01', 500000),
('Puma', 'P1', 'Puma đế nâu', 36, 'trắng nâu', 5, 'NSX03', 300000),
('Puma', 'P2', 'Puma phản quang', 39, 'trắng', 20, 'NSX03', 350000),
('Puma', 'P3', 'Puma phản quang', 37, 'trắng', 15, 'NSX03', 350000),
('Vans', 'V1', 'Vans Slip On', 38, 'trắng đen', 4, 'NSX02', 350000),
('Vans', 'V2', 'Vans Slip On', 37, 'trắng đen', 10, 'NSX02', 350000),
('Vans', 'V3', 'Vans Slip On', 40, 'trắng đen', 5, 'NSX02', 400000),
('Vans', 'V4', 'Vans Slip On', 39, 'trắng', 3, 'NSX02', 445000);

-- --------------------------------------------------------

--
-- Table structure for table `taikhoan`
--

CREATE TABLE `taikhoan` (
  `maTK` varchar(50) NOT NULL,
  `tenDN` varchar(50) NOT NULL,
  `matkhau` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `taikhoan`
--

INSERT INTO `taikhoan` (`maTK`, `tenDN`, `matkhau`) VALUES
('TK01', 'admin', 'admin'),
('TK02', 'admin2', 'admin2'),
('TK03', 'dong', 'dong'),
('TK04', 'nhi', 'nhi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chitiethd`
--
ALTER TABLE `chitiethd`
  ADD KEY `maHD` (`maHD`),
  ADD KEY `maSP` (`maSP`),
  ADD KEY `maKH` (`maKH`);

--
-- Indexes for table `hoadon`
--
ALTER TABLE `hoadon`
  ADD PRIMARY KEY (`maHD`);

--
-- Indexes for table `khachhang`
--
ALTER TABLE `khachhang`
  ADD PRIMARY KEY (`maKH`);

--
-- Indexes for table `loaisanpham`
--
ALTER TABLE `loaisanpham`
  ADD PRIMARY KEY (`maloaiSP`);

--
-- Indexes for table `nhanvien`
--
ALTER TABLE `nhanvien`
  ADD PRIMARY KEY (`maNV`),
  ADD KEY `maTK` (`maTK`);

--
-- Indexes for table `nhasanxuat`
--
ALTER TABLE `nhasanxuat`
  ADD PRIMARY KEY (`maNSX`);

--
-- Indexes for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`maSP`),
  ADD KEY `maloaiSP` (`maloaiSP`),
  ADD KEY `maNSX` (`maNSX`);

--
-- Indexes for table `taikhoan`
--
ALTER TABLE `taikhoan`
  ADD PRIMARY KEY (`maTK`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chitiethd`
--
ALTER TABLE `chitiethd`
  ADD CONSTRAINT `chitiethd_ibfk_1` FOREIGN KEY (`maHD`) REFERENCES `hoadon` (`maHD`),
  ADD CONSTRAINT `chitiethd_ibfk_2` FOREIGN KEY (`maSP`) REFERENCES `sanpham` (`maSP`),
  ADD CONSTRAINT `chitiethd_ibfk_3` FOREIGN KEY (`maKH`) REFERENCES `khachhang` (`maKH`);

--
-- Constraints for table `nhanvien`
--
ALTER TABLE `nhanvien`
  ADD CONSTRAINT `nhanvien_ibfk_1` FOREIGN KEY (`maTK`) REFERENCES `taikhoan` (`maTK`);

--
-- Constraints for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD CONSTRAINT `sanpham_ibfk_1` FOREIGN KEY (`maNSX`) REFERENCES `nhasanxuat` (`maNSX`),
  ADD CONSTRAINT `sanpham_ibfk_2` FOREIGN KEY (`maloaiSP`) REFERENCES `loaisanpham` (`maloaiSP`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
